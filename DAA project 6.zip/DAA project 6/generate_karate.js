// Helper script to generate Zachary's Karate Club adjacency matrix
// This is the standard 34-node social network dataset (0-indexed)
const fs = require('fs');
const path = require('path');

const N = 34;
const matrix = Array.from({length: N}, () => Array(N).fill(0));

// Edge list from Zachary's Karate Club (0-indexed, undirected)
const edges = [
  [0,1],[0,2],[0,3],[0,4],[0,5],[0,6],[0,7],[0,8],[0,10],[0,11],[0,12],[0,13],[0,17],[0,19],[0,21],[0,31],
  [1,2],[1,3],[1,7],[1,13],[1,17],[1,19],[1,21],[1,30],
  [2,3],[2,7],[2,8],[2,9],[2,13],[2,27],[2,28],[2,32],
  [3,7],[3,12],[3,13],
  [4,6],[4,10],
  [5,6],[5,10],[5,16],
  [6,16],
  [8,30],[8,32],[8,33],
  [9,33],
  [13,33],
  [14,32],[14,33],
  [15,32],[15,33],
  [18,32],[18,33],
  [19,33],
  [20,32],[20,33],
  [22,32],[22,33],
  [23,25],[23,27],[23,29],[23,32],[23,33],
  [24,25],[24,27],[24,31],
  [25,31],
  [26,29],[26,33],
  [27,33],
  [28,31],[28,33],
  [29,32],[29,33],
  [30,32],[30,33],
  [31,32],[31,33],
  [32,33]
];

// Assign weights: use varied weights based on connectivity patterns
// Hub-to-hub connections get higher weights (more interaction)
const degrees = Array(N).fill(0);
edges.forEach(([i,j]) => { degrees[i]++; degrees[j]++; });

edges.forEach(([i,j]) => {
  // Weight based on geometric mean of degrees, scaled 1-5
  const w = Math.max(1, Math.min(5, Math.round(Math.sqrt(degrees[i] * degrees[j]) / 3)));
  matrix[i][j] = w;
  matrix[j][i] = w;  // undirected = symmetric
});

// Verify
let edgeCount = 0;
for(let i=0; i<N; i++) for(let j=i+1; j<N; j++) if(matrix[i][j] > 0) edgeCount++;
console.log(`Nodes: ${N}, Edges: ${edgeCount}`);
console.log(`Degrees:`, degrees);

// Write to file
const outputDir = path.join(__dirname, 'public', 'datasets');
fs.mkdirSync(outputDir, {recursive: true});
fs.writeFileSync(path.join(outputDir, 'karate.json'), JSON.stringify(matrix));
console.log('Written to public/datasets/karate.json');
